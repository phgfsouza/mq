# Carrega bibliotecas 
install.packages('tidyverse')
install.packages('png')
install.packages('readx1')
install.packages('scales')
install.packages('summarytools')
install.packages('writex1')
install.packages('questionr')
install.packages('summarytools')
install.packages('Rtools')
install.packages('xlsReadWrite') 
install.packages('plyr') 

# Instala bibliotecas
library(tidyverse)
library(png)
library(readx1)
library(scales)
library(summarytools)
library(writex1)
library(questionr)
library(summarytools)
library(Rtools)
library(xlsReadWrite)

# Ler dados da PNAD-C de 2016 para o R
# O formato é CSV, que é um formato cada vez mais popular
# O comando do R é read.csv
PNAD <- read.csv(file="C:/Users/Sergei/ownCloud/Curso Metodos/visita1_2016.csv", header=TRUE, sep=";")

# Tem o comando names para trocar nomes de variáveis
names(PNAD)[names(PNAD) == "vd3005"] <- "anos_estudo"
names(PNAD)[names(PNAD) == "vd4009"] <- "posicao"
names(PNAD)[names(PNAD) == "vd4010"] <- "setor"
names(PNAD)[names(PNAD) == "vd4011"] <- "ocupacao"
names(PNAD)[names(PNAD) == "vd4016"] <- "rendimento"
names(PNAD)[names(PNAD) == "vd5005"] <- "renda_pc"


# Tem o comando factor para colocar labels nos valores de certas variáveis  
PNAD$setor <- factor(PNAD$setor,
levels = c(1,2,3,4,5,6,7,8,9,10,11,12),
labels = c("Agricultura", "Indústria","Construção","Comércio automotores","Transporte","Alojamento e alimentação", "Profissionais", "Administração pública","Serviços sociais", "Outros Serviços","Serviços domésticos", "Mal definidas")) 

PNAD$posicao <- factor(PNAD$posicao,
levels = c(1,2,3,4,5,6,7,8,9,10),
labels = c("Empregado com carteira", "Empregado sem carteira", "Doméstico com carteira", "Doméstico sem carteira", "Setor público com carteira", "Setor público sem carteira", "Militar e estatutário", "Empregador", "Conta-própria", "Familiar")) 

PNAD$ocupacao <- factor(PNAD$ocupacao,
levels = c(1,2,3,4,5,6,7,8,9,10,11),
labels = c("Diretores e gerentes", "Ciências e intelectuais", "Profissionais de nível médio", "Apoio administrativo", "Serviços e vendedores", "Qualificados agropecuária", "Qualificados construção e outros ofícios", "Operadores de máquinas", "Ocupações elementares", "Forças armadas, policiais e bombeiros", "Ocupações maldefinidas ")) 

# Vamos verificar as tabelas
table(PNAD$setor, PNAD$posicao)
table(PNAD$ocupacao, PNAD$posicao)
table(PNAD$setor, PNAD$ocupacao)

# O resultado nao pode ser so zeros






