

# Agora vamos ver correlacoes

preamostra <- na.omit(PNAD, cols=setor(PNAD), invert=FALSE)
amostra <- sample_n(preamostra,100, na.rm=TRUE)
write.table(amostra, file="C:/Users/Sergei/ownCloud/Curso Metodos/amostra.csv", sep=',')

# Cálculo de correlações no Excel
 
# De volta ao R
# Calcular as correlações no R
cor(amostra$rendimento,amostra$anos_estudo)

# Vamos voltar a amostra completa
cor(PNAD$rendimento,PNAD$anos_estudo)

# Missing de novo!
# Varias op'ções para lidar com missings
cor(PNAD$rendimento,PNAD$anos_estudo, use = "everything")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "all.obs")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "complete.obs")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "na.or.complete")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "pairwise.complete.obs")

# Logs 
# Vamos agora trabalhar com logs 
PNAD$log_rend = log(PNAD$rendimento)
cor(PNAD$log_rend,PNAD$anos_estudo, use = "na.or.complete", method ="pearson") 


## Outros aspectos de relações entre duas variáveis 
## Tabulacaoes condicionais 
## Tabulacaoes com duas ou mais condicoes
## Tabluacaoes com condicoes mais complexas

# Tabela em posicao condicional a setor == agricultura
soagricola <- PNAD[ which(PNAD$setor=='Agricultura'),]
posicao_agricola <- table(soagricola$posicao)
posicao_agricola
remove(soagricola)
remove(posicao_agricola)

# Tabela em posicao condicional a setor == agricultura e anos_estudo == 11
so_agricola_e_11 <- PNAD[ which(PNAD$setor=='Agricultura' & PNAD$anos_estudo == 11),]
posicao_agricola11 <- table(so_agricola_e_11$posicao)
posicao_agricola11
remove(so_agricola_e_11)
remove(posicao_agricola11)

# Tabela em posicao condicional a remuneracao ser menor que a media 
media <- mean(PNAD$rendimento, na.rm=TRUE)
remunera_baixa <- PNAD[ which(PNAD$rendimento < media),]
table(remunera_baixa$posicao)
remove(remunera_baixa)


### Quantis
# Como achar a mediana  
quantile(PNAD$renda_pc, c(.5), na.rm=TRUE)

# E a divisao entre terco superior e terco inferior 
quantile(PNAD$renda_pc, c(.333, 0.666), na.rm=TRUE)

# E a divisao em dez?
decimos <- quantile(PNAD$renda_pc, c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1), na.rm=TRUE)

# Jogar para o excel 
write.table(decimos, file="C:/Users/Sergei/ownCloud/Curso Metodos/decimos.csv", sep=';')

# Outras medidas de disperção e análise distributiva

# Fazer quantis e curva de lorenz sem usar o comando quantile
ordenada <- PNAD[order(PNAD$renda_pc),]
ordenada <- na.omit(ordenada, cols="renda_pc")
ordenada$one <- 1
ordenada$cumulativo <- cumsum(ordenada$one)
maximo <- max(ordenada$cumulativo) 
ordenada$centil <- 1+trunc(100*(ordenada$cumulativo/maximo))
ordenada$centil <- ordenada$centil-trunc((ordenada$centil/101))

aggregate(ordenada$renda_pc, by=list(ordenada$centil), FUN=mean , na.rm=TRUE) 


## Calcular pobreza
PNAD$pobre <- ifelse(PNAD$renda_pc < 250, 1, 0)
mean(PNAD$pobre, na.rm=TRUE)

## Pobreza x setor de ocupacao usando aggregate e usando table 
# Table
table(PNAD$setor,PNAD$pobre)

# Aggregate 
aggregate(PNAD$pobre, by=list(PNAD$setor), FUN=mean , na.rm=TRUE) 

# Calcula a pobreza extrema (linha de 100)
PNAD$pobre_ext <- ifelse(PNAD$renda_pc < 100, 1, 0)
mean(PNAD$pobre_ext, na.rm=TRUE)

