# anotacoes - na.omit nao, media e mediana da distribui??o, dependencia entre variaveis, desvio medio absoluto


# Configuracoes

  # Pasta de trabalho (alterar para o caminho correto no computador de voces)
    setwd("c:/ipea/onedrive/work/Incompletos/aulas/metodos_quant/modulo2/dados")
    
  # Pacotes
    library(readr)
    library(dplyr)
    library(ggplot2)
    library(summarytools)


# Carregando a Bases de dados
  data <- read_csv("datafolha_oxfam.csv")

# Observacao importante: alguns alunos aplicaram a funcao 'na.omit' aos dados. Nao facam isso - essa
# funcao descarta todas as observacoes com algum valor missing ('NA') em qualquer variavel.
  
  
### PERGUNTA 01 ###
  
# Uma das perguntas do questionario pediu para os entrevistados escolherem, em uma lista de oito
# fatores, qual o mais importante para 'ter uma vida melhor daqui para frente'. Leia o dicionario de
#  variaveis, identifique a variavel correspondente a essa pergunta e reporte:
    
# a) A tabela de frequencias absolutas e relativas para a amostra como um todo, indicando a opcao
# mais popular e o percentual de votos recebidos.
  freq(data$p18)
  # ... logo, a resposta mais popular foi 'fe religiosa', com 580 votos (27.80% da amostra)

# b) as tabelas de frequências absolutas e relativas para pessoas com renda familiar de até R$ 998 e
# para pessoas com renda famíliar maior ou igual a R$ 9981. Qual a principal diferença entre as
# respostas desses dois grupos?
  data$renda_familiar<- factor(data$renda_familiar, levels = c('R$ 0 a 998','R$ 999 a 1996', 'R$ 1997 a 2994', 
                                                                'R$ 2995 a 4990','R$ 4991 a 9980', 'R$ 9981 ou mais'))
  data %>% filter(renda_familiar=='R$ 0 a 998') %>% freq(p18) 
  data %>% filter(renda_familiar=='R$ 9981 ou mais') %>% freq(p18)
  # ...logo, a principal semelhanca e' que ambas as faixas de renda colocaram 'fe religiosa' em primeiro lugar;
  # ja' a principal diferenca e' que, entre os mais pobres, ter acesso a saude vem em segundo lugar e ter acesso
  # a aposentadoria vem quinto; entre os ricos, essas opcoes foram bem menos populares, e 'estudar' veio em segundo.
    
 
### PERGUNTA 02 ###   
  
# Outra pergunta do questionario pediu para os entrevistados localizarem sua posicao na distribuicao de
# renda. Leia o dicionario de variáveis, identique a variáavel correspondente a essa pergunta e reporte:  

# a) Qual o percentual dos entrevistados que acha que esta exatamente na mediana da distribuicao de renda?
  freq(data$p13)
  #... 501 entrevistados (24.02%) acham que estão na mediana.
  # Observação: alguns alunos se confundiram e reportaram o valor mediano da variavel, mas a pergunta era
  # sobre a interpretacao do conteudo da variavel.
  
  
# b) Qual o percentual dos entrevistados que acha que esta entre os 20% mais ricos? E entre os 20% mais pobres?
  freq(data$p13)
  #... 2.4% acham que estao entre os 20% mais ricos e 36.91% acham que estao entre os 20% mais pobre
  
# c) Qual o valor medio dessa variavel? Como interpreta-lo?
  descr(data,p13)
  #... o valor medio e' de 34.35. Ou seja, em media, os entrevistados acham que estao no percentil 34 (isto e',
  # acham que sao mais pobres do que 2/3 da populacao)
  
# d) Se todos soubessem com total precisão sua posição na distribuição de renda, qual seria o valor 
# médio dessa variável? E o valor mediano?  
  #... assumindo que a amostra e' representativa de toda a distribuicao de renda, 
  # se todos soubessem com total precisao o valor medio e o mediano seriam 50.
    
  
### PERGUNTA 03 ###
  
# Vamos agora analisar a composição demografica por cada faixa de renda familiar. Responda:
  
# a) Existe alguma associacao entre sexo e renda familiar ou elas sao independentes? Caso exista, 
# descreva o padrao observado.
  data %>% group_by(renda_familiar) %>%  freq(sexo)
  #... sim, o percentual de mulheres cai 'a medida que a renda aumenta.
  
# b)  Em qual(is) faixas de renda os pardos e pretos sao maioria?
  data %>% group_by(renda_familiar) %>%  freq(cor_raca)
  #... pretos e pardos sao maioria em todas as faixas abaixo de R$ 4491
# c) Qual faixa de renda familiar possui a maior media de idade? Qual possui a menor? 
  data %>% group_by(renda_familiar) %>%  descr(idade)
  #... maior é na faixa de renda mais baixa (0-998) e a menor de R$ 2995 a 4990
  

### PERGUNTA 04 ###
  
# Identifique a variavel que registra a renda que cada entrevistado julga ser necessaria para uma pessoa
# estar entre os 10% mais ricos. Responda:
    
# a) Calcule a media e a mediana. O que esses resultados sugerem?
  options(scipen=999)
  descr(data,p19)
  #.. média de 17044874.28, mediana de 30000.00. A media e' altamente influenciada pela existencia de outliers
  # com valores absurdos, mas a mediana nao.
  
# b) Calcule os percentis 25 e 75 e a amplitude interquartil e interprete os resultados.
  descr(data,p19)
  #... P25 e' de 8000, P75 de 200,000. Ou seja, metade dos respondentes acha que e' preciso algo entre 8 e 200 mil
  # para estar entre os 10% mais ricos.
  
# c) Calcule o desvio medio absoluto e o desvio padrão e compare os resultados.
  descr(data,p19)
  #... desvio medio absoluto e' de 40030, o desvio padrao e' de 114842502.96, valor muito superior porque
  # o desvio padrao e' mais sensivel 'a presenca de outliers com valores extremos.
  
# d) Calcule os percentis 25, 50 (mediana) e 75 para cada faixa de renda e interprete os resultados.
  data %>% group_by(renda_familiar) %>% descr(p19)
  #... quanto mais alta a renda familiar, maior a renda exigida para estar entre os mais ricos. 
  
# e) Faça um histograma com 100 bins. Interprete o resultado.  
  ggplot( data = data, aes(x = p19)) + geom_histogram( bins = 100)
  #... visualizacao comprometida pela presenca de poucos outliers!
  
  
### PERGUNTA 05 ###
  
# O questionario pediu aos entrevistados para se classificarem de acordo com seu grupo ou classe social
# no passado, no presente e suas expectativas para o futuro. Identifique essas variáveis e responda:
 
# a) Qual o percentual de entrevistados que nao teve mobilidade social nos ultimos cinco anos? 
# (Ou seja, qual o percentual que afirmou pertencer hoje ao mesmo grupo ou classe social em que estava
# cinco anos atras.)
  data$p14f <- factor(data$p14, levels = c('Pobre','Classe média baixa','Classe média', 'Classe média alta', 'Rico'))
  data$p15f <- factor(data$p15, levels = c('Pobre','Classe média baixa','Classe média', 'Classe média alta', 'Rico'))
  table(data$p14f, data$p15f)
  (239 + 590 + 338 + 17 + 2) / 2070
  #... 57.3%.
  
# b) Qual o percentual de entrevistados que espera ter mobilidade social ascendente no futuro?
  data$p17f <- factor(data$p17, levels = c('Pobre','Classe média baixa','Classe média', 'Classe média alta', 'Rico'))
  table(data$p14f, data$p17f)  
  (94+115+20+9+502+222+27+365+41+14)/1997
  #... 70.5%.

# c) Escolha uma das tres variaveis, faça um grafico de barras somente para os moradores da regiao
# Nordeste e interprete os resultados.
  data %>% filter(regiao == 'Nordeste') %>%  ggplot(aes(x = p14f)) + geom_bar()
  


### PERGUNTA 06 ###
  
# As variaveis p27a, p27b, p27c, p27d e p27e medem a importancia dada pelos entrevistados a di-
# versas politicas de reducao da desigualdade. Consulte o dicionario de variaveis e responda:

# a) Qual o instrumento de combate a desigualdade com maior nota media? Qual foi a nota? Qual
# o com a menor nota media? Qual foi a nota?
  mean(data$p27a, na.rm = TRUE)
  mean(data$p27b, na.rm = TRUE)
  mean(data$p27c, na.rm = TRUE)
  mean(data$p27d, na.rm = TRUE)
  mean(data$p27e, na.rm = TRUE)
  #... maior media para combate 'a corrupcao (9.68), menor para assistencia social (7.77)
  
# b) Calcule a matriz de correlações dessas cinco variaveis, isto e', calcule todas as 25 correlacoes
# possiveis entre elas. Qual a maior correlaco? O que isso significa?
  cmatrix <- as.matrix( cbind(data$p27a, data$p27b, data$p27c, data$p27d, data$p27e) )
  cor(cmatrix, use = "pairwise.complete.obs")
  #... maior correlacao eh 0.4286, entre p27b e p27c (emprego e educacao).

# c) Qual variável traz as notas para 'cobrar mais impostos para os mais ricos'? Faça um grafio
# box plot dessa variavel, colocando as faixas de renda familiar no eixo horizontal. Interprete os
# resultados.
 ggplot( data = subset(data, !is.na(p27a) & !is.na(renda_familiar)), aes(x = renda_familiar, y=p27a)) + geom_boxplot()
 #... quanto mais rico, menos apoio 'a tributacao dos ricos.

 
