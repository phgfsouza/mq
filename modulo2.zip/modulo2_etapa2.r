
# Carrega bibliotecas 
install.packages('tidyverse')
install.packages('dplyr')
install.packages('ggplot2')
install.packages('png')
install.packages('readr')
install.packages('readx1')
install.packages('scales')
install.packages('summarytools')
install.packages('writex1')
install.packages('questionr')
install.packages('summarytools')
install.packages('Rtools')
install.packages('xlsReadWrite') 
install.packages('plyr') 

# Instala bibliotecas
library(tidyverse)
library(summarytools)
library(slxReadWrite)

# Ler dados da PNAD-C de 2016 para o R
# O formato é CSV, que é um formato cada vez mais popular
# O comando do R é read.csv
PNAD <- read.csv(file="C:/Users/Sergei/ownCloud/Curso Metodos/visita1_2016.csv", header=TRUE, sep=";")

# Vejam que na lista de objetos apareceu um objeto chamado PNAD 


# Agora vamos dar uma olhada em vários comando que resumem os dados que estao no Dataframe PNAD

# Mostra o tipo de objeto - verificar que é mesmo um dataframe
class(PNAD)

# Mostra que tipo de variaveis tenho
str(PNAD)
# Um monte de variaveis inteiras com nomes pouco interessantes

# Olhar os primeiros n dados (mesma coisa que clicar na base)
head(PNAD, n=10)
# De novo variaveis com nomes pouoc intuitivos

# Vamos ver minimos, médias, e máximo das variaveis  que temos na PNAD
summary(PNAD)


# Conclusão: Nomes meio ruins
#Vamos trocar os nomes?
# Tem o ocmando names
names(PNAD)[names(PNAD) == "vd3005"] <- "anos_estudo"

names(PNAD)[names(PNAD) == "vd4009"] <- "posicao"

names(PNAD)[names(PNAD) == "vd4010"] <- "setor"

names(PNAD)[names(PNAD) == "vd4011"] <- "ocupacao"

names(PNAD)[names(PNAD) == "vd4016"] <- "rendimento"

names(PNAD)[names(PNAD) == "vd5005"] <- "renda_pc"

# Vamos verificar como ficou
head(PNAD, n=10)

# Agora ficou mais facil verificar o que temos 
summary(PNAD)

# Beeem melhor

# Frequencias 
# Vamos comparar os comandos table e freq

# table
table(PNAD$setor)

# freq
freq(PNAD$setor, headings=FALSE, round.digits=1)
tabela1 <- freq(PNAD$setor, headings=FALSE, round.digits=1) 

# freq é bem melhor, mas table tem vantagens
table(PNAD$setor, PNAD$posicao)
 
tabela2 <- table(PNAD$setor, PNAD$posicao)
margin.table(tabela2,1)
margin.table(tabela2,2)

# Voltamos ao comando freq 
freq(PNAD$setor, headings=FALSE, round.digits=1)

# Valores codificam nomes, vamos botar labels nos nomes?
# O comando se chama factor (vai entender)
# Prestem atenção nos parenteses
  
PNAD$setor <- factor(PNAD$setor,
levels = c(1,2,3,4,5,6,7,8,9,10,11,12),
labels = c("Agricultura", "Indústria","Construção","Comércio automotores","Transporte","Alojamento e alimentação", "Profissionais", "Administração pública","Serviços sociais", "Outros Serviços","Serviços domésticos", "Mal definidas")) 

# Alem do setor, temos posicao e ocupacao
# Exercicio

PNAD$posicao <- factor(PNAD$posicao,
levels = c(1,2,3,4,5,6,7,8,9,10),
labels = c("Empregado com carteira", "Empregado sem carteira", "Doméstico com carteira", "Doméstico sem carteira", "Setor público com carteira", "Setor público sem carteira", "Militar e estatutário", "Empregador", "Conta-própria", "Familiar")) 

PNAD$ocupacao <- factor(PNAD$ocupacao,
levels = c(1,2,3,4,5,6,7,8,9,10,11),
labels = c("Diretores e gerentes", "Ciências e intelectuais", "Profissionais de nível médio", "Apoio administrativo", "Serviços e vendedores", "Qualificados agropecuária", "Qualificados construção e outros ofícios", "Operadores de máquinas", "Ocupações elementares", "Forças armadas, policiais e bombeiros", "Ocupações maldefinidas ")) 

# Vamos ver se teve efeito sobre freq e table
table(PNAD$setor, PNAD$posicao)
freq(PNAD$setor, headings=FALSE, round.digits=1)

# Beleza pura

# Agora que ta tudo bonitinho, vamos fazer análise de variancia
# Começa com uma média condicionada de rendimento por 
# Comando aggregate

# Medias condicionadas
aggregate(PNAD$rendimento, by=list(PNAD$ocupacao), mean)

#Eita! So tem missing! Por que a média de algo que tem missing é ... missing

# Duas maneiras de tirar msissing
# Primeira (complicada) tira os missing do dataframe e faz o aggregate 

sem_missing_setor <- na.omit(PNAD, cols=setor(PNAD), invert=FALSE)
medias <- aggregate(sem_missing_setor$rendimento, by=list(sem_missing_setor$ocupacao), mean)
write.table(medias, file="C:/Users/Sergei/ownCloud/Curso Metodos/medias.csv", sep=';')

# Segunda (bem mais facil) manda o aggregate ignorar os missings 
variancias <- aggregate(PNAD$rendimento, by=list(PNAD$ocupacao), FUN=mean , na.rm=TRUE)
write.table(variancias, file="C:/Users/Sergei/ownCloud/Curso Metodos/variacias.csv", sep=';')

# Eu prefiro o segundo 

# Exercicio: fazer aggregate usando funções max, min, var e sum 


# Agora vamos fazer anaises bivariados 

# Primeiro, associação bivariada
# Exercicio: Table entre posicao e setor

tabela1 <- table(PNAD$setor, PNAD$posicao)

# Como exportar usando csv 
write.table(tabela1, file="C:/Users/Sergei/ownCloud/Curso Metodos/tabela1.csv", sep=';')

# Exercicio: façam tabelas setor x ocuapcao e ocuapcao x posicao e exportem para o XL
tabela2 <- table(PNAD$setor, PNAD$ocupacao)
write.table(tabela1, file="C:/Users/Sergei/ownCloud/Curso Metodos/tabela2.csv", sep=';')

tabela3 <- table(PNAD$ocupacao, PNAD$posicao)
write.table(tabela1, file="C:/Users/Sergei/ownCloud/Curso Metodos/tabela3.csv", sep=';')

# Agora vamos ver correlacoes

amostra <- sample_n(sem_missing_setor,100, na.rm=TRUE)
write.table(amostra, file="C:/Users/Sergei/ownCloud/Curso Metodos/amostra.csv", sep=';')

# Fazer uma tabela de associações

# Calcular as correlacoes no XL

# Calcular as correlações no R
cor(amostra$rendimento,amostra$anos_estudo)

# Vamos voltar a amostra completa
cor(PNAD$rendimento,PNAD$anos_estudo)

# Missing de novo!
# Varias op'ções para lidar com missings
cor(PNAD$rendimento,PNAD$anos_estudo, use = "everything")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "all.obs")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "complete.obs")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "na.or.complete")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "pairwise.complete.obs")


# Vamos agora trabalhar com logs 
PNAD$log_rend = log(PNAD$rendimento)

# Fazer o log na amostra
amostra$log_rend = log(amostra$rendimento)
cor(PNAD$log_rend,PNAD$anos_estudo, use = "na.or.complete", method ="pearson")

write.table(amostra, file="C:/Users/Sergei/ownCloud/Curso Metodos/amostralog.csv", sep=';')


# Agora estamos prontos para fazer analise de variancia, vamos comparar quem explica melhor o rendimento, setor, ocupacao ou posicao na ocupacao

aggregate(PNAD$rendimento, by=list(PNAD$ocupacao), FUN=mean , na.rm=TRUE) 
aggregate(PNAD$rendimento, by=list(PNAD$posicao), FUN=mean , na.rm=TRUE)
aggregate(PNAD$rendimento, by=list(PNAD$setor), FUN=mean , na.rm=TRUE)

aggregate(PNAD$rendimento, by=list(PNAD$ocupacao), FUN=var , na.rm=TRUE) 
aggregate(PNAD$rendimento, by=list(PNAD$posicao), FUN=var , na.rm=TRUE)
aggregate(PNAD$rendimento, by=list(PNAD$setor), FUN=var , na.rm=TRUE)

freq(PNAD$ocupacao, headings=FALSE, round.digits=1)
freq(PNAD$posicao, headings=FALSE, round.digits=1)
freq(PNAD$setor, headings=FALSE, round.digits=1)

# Dever de casa: descobrir qual das divisões (setor, ocupação, posição) "explica" melhor a variancia do rendimento



# Outras medidas de disperção e análise distributiva

# Fazer quantis e curva de lorenz

ordenada <- PNAD[order(PNAD$renda_pc),]
ordenada <- na.omit(ordenada, cols="renda_pc")
ordenada$one <- 1
ordenada$cumulativo <- cumsum(ordenada$one)
maximo <- max(ordenada$cumulativo) 
ordenada$centil <- 1+trunc(100*(ordenada$cumulativo/maximo))
ordenada$centil <- ordenada$centil-trunc((ordenada$centil/101))

aggregate(ordenada$renda_pc, by=list(ordenada$centil), FUN=mean , na.rm=TRUE) 

