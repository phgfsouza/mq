

setwd("D:/OneDrive/work/Incompletos/aulas/metodos_quant/modulo2/dados")

library(readr)
library(dplyr)
library(ggplot2)
library(summarytools)

data <- read_csv("datafolha_oxfam.csv")


# Factors
  data$renda_familiar<- factor(data$renda_familiar, levels = c('R$ 0 a 998','R$ 999 a 1996', 'R$ 1997 a 2994', 
                                                                 'R$ 2995 a 4990','R$ 4991 a 9980', 'R$ 9981 ou mais'))
  data$p14 <- factor(data$p14, levels = c('Pobre','Classe média baixa','Classe média', 'Classe média alta', 'Rico'))
  data$p15 <- factor(data$p15, levels = c('Pobre','Classe média baixa','Classe média', 'Classe média alta', 'Rico'))
  data$p17 <- factor(data$p17, levels = c('Pobre','Classe média baixa','Classe média', 'Classe média alta', 'Rico'))

  
# 1
  freq(data$p18)
  data %>% filter(renda_familiar=='R$ 9981 ou mais') %>% freq(p18)
  data %>% filter(renda_familiar=='R$ 0 a 998') %>% freq(p18) 
  
#2 
  descr(data,p13)
  freq(data$p13)
  
#3
  data %>% group_by(renda_familiar) %>%  freq(cor_raca)
  data %>% group_by(renda_familiar) %>%  freq(sexo)
  data %>% group_by(renda_familiar) %>%  descr(idade)


#4 
  descr(data,p19)
  data %>% group_by(renda_familiar) %>% descr(p19)
  ggplot( data = data, aes(x = p19)) + geom_histogram( bins = 100)

  
#5 
  table(data$p14, data$p15)
  table(data$p14, data$p17) 
  data %>% filter(regiao == 'Nordeste') %>% ggplot(aes(x = p15)) + geom_bar()
  
  
#6 
 mean(data$p27a, na.rm = TRUE)
 mean(data$p27b, na.rm = TRUE)
 mean(data$p27c, na.rm = TRUE)
 mean(data$p27d, na.rm = TRUE)
 mean(data$p27e, na.rm = TRUE)
 cmatrix <- as.matrix( cbind(data$p27a, data$p27b, data$p27c, data$p27d, data$p27e) )
 cor(cmatrix, use = "pairwise.complete.obs")
 ggplot( data = subset(data, !is.na(p27a) & !is.na(renda_familiar)), aes(x = renda_familiar, y=p27a)) + geom_boxplot()
 
#7 
 
