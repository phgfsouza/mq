# Ja limos a base, trocamos os nomes das variáveis, recodificamos variaveis categoricas, e tiramos frequencias 
# Ultima coisa: vamos ver como observar as tabelas no Excel

# Façam tabelas setor x ocuapcao e ocuapcao x posicao e exportem para o XL
tabela1 <- table(PNAD$setor, PNAD$ocupacao)
write.table(tabela1, file="C:/Users/Sergei/ownCloud/Curso Metodos/tabela1.csv", sep=',')

# Exercício: façam agora setor x posicao e ocupacao x posicao


# Vamos agora fazer análise de variancia 


# Vamos fazer no Excel e depois no R

# Primeiro um exercício no Excel
# calcule a variancia de 1,2,3,4,5,
 
# Voltando à PNAD calcule a variancia do rendimento particionada de acordo com a posição na ocupação
# Para isso vamos precisar de seis passos no R

# Medias condicionadas
medias <- aggregate(PNAD$rendimento, by=list(PNAD$ocupacao), FUN=mean , na.rm=TRUE)
write.table(medias, file="C:/Users/Sergei/ownCloud/Curso Metodos/medias.csv", sep=',')

# Variancias internas
variancias <- aggregate(PNAD$rendimento, by=list(PNAD$ocupacao), FUN=var , na.rm=TRUE)
write.table(variancias, file="C:/Users/Sergei/ownCloud/Curso Metodos/variancias.csv", sep=',')
 
# Tamanho da população
totais <- table(PNAD$ocupacao)
write.table(totais, file="C:/Users/Sergei/ownCloud/Curso Metodos/totais.csv", sep=',')

# Vamos agora ver o cálculo da variancia no Excel
 
# Dever de casa: façam o mesmo com setor e posicao e descubram qual particao explcia melhor a variacia dos rendimentos

# Agora vamos ver correlacoes

preamostra <- na.omit(PNAD, cols=setor(PNAD), invert=FALSE)
amostra <- sample_n(preamostra,100, na.rm=TRUE)
write.table(amostra, file="C:/Users/Sergei/ownCloud/Curso Metodos/amostra.csv", sep=',')

# Cálculo de correlações no Excel
 
# De volta ao R
# Calcular as correlações no R
cor(amostra$rendimento,amostra$anos_estudo)

# Vamos voltar a amostra completa
cor(PNAD$rendimento,PNAD$anos_estudo)

# Missing de novo!
# Varias op'ções para lidar com missings
cor(PNAD$rendimento,PNAD$anos_estudo, use = "everything")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "all.obs")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "complete.obs")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "na.or.complete")
cor(PNAD$rendimento,PNAD$anos_estudo, use = "pairwise.complete.obs")
 
 
# Logs 
# Vamos agora trabalhar com logs 
PNAD$log_rend = log(PNAD$rendimento)
cor(PNAD$log_rend,PNAD$anos_estudo, use = "na.or.complete", method ="pearson") 
 
# Fazer quantis e curva de lorenz

ordenada <- PNAD[order(PNAD$renda_pc),]
ordenada <- na.omit(ordenada, cols="renda_pc")
ordenada$one <- 1
ordenada$cumulativo <- cumsum(ordenada$one)
maximo <- max(ordenada$cumulativo) 
ordenada$centil <- 1+trunc(100*(ordenada$cumulativo/maximo))
ordenada$centil <- ordenada$centil-trunc((ordenada$centil/101))

aggregate(ordenada$renda_pc, by=list(ordenada$centil), FUN=mean , na.rm=TRUE) 
